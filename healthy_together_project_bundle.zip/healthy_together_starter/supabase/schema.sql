-- Healthy Together starter schema. Review/test before production use.
create extension if not exists pgcrypto;

create table if not exists public.households (
  id uuid primary key default gen_random_uuid(),
  name text not null default 'Healthy Together',
  created_at timestamptz not null default now()
);

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null,
  household_id uuid references public.households(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.habits (
  id uuid primary key default gen_random_uuid(),
  household_id uuid not null references public.households(id) on delete cascade,
  title text not null,
  points integer not null check (points >= 0),
  target_per_week integer not null default 1 check (target_per_week >= 0),
  owner_user_id uuid references auth.users(id) on delete cascade,
  shared boolean not null default false,
  sort_order integer not null default 0,
  active boolean not null default true
);

create table if not exists public.check_ins (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  habit_id uuid not null references public.habits(id) on delete cascade,
  checkin_date date not null default current_date,
  completed boolean not null default true,
  created_at timestamptz not null default now(),
  unique(user_id, habit_id, checkin_date)
);

create table if not exists public.rewards (
  id uuid primary key default gen_random_uuid(),
  household_id uuid not null references public.households(id) on delete cascade,
  title text not null,
  points_cost integer not null default 50 check (points_cost >= 0),
  reward_type text not null check (reward_type in ('personal', 'shared')),
  owner_user_id uuid references auth.users(id) on delete cascade,
  active boolean not null default true
);

create table if not exists public.reward_claims (
  id uuid primary key default gen_random_uuid(),
  reward_id uuid not null references public.rewards(id) on delete cascade,
  claimed_by uuid not null references auth.users(id) on delete cascade,
  claimed_at timestamptz not null default now(),
  status text not null default 'claimed' check (status in ('claimed', 'completed', 'cancelled'))
);

create table if not exists public.weight_entries (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  entry_date date not null default current_date,
  weight numeric(6,2) not null check (weight > 0),
  note text,
  created_at timestamptz not null default now(),
  unique(user_id, entry_date)
);

create table if not exists public.wins (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  win_date date not null default current_date,
  description text not null,
  bonus_points integer not null default 0 check (bonus_points >= 0 and bonus_points <= 5),
  created_at timestamptz not null default now()
);

create or replace function public.is_household_member(target_household uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles p
    where p.id = auth.uid() and p.household_id = target_household);
$$;

alter table public.households enable row level security;
alter table public.profiles enable row level security;
alter table public.habits enable row level security;
alter table public.check_ins enable row level security;
alter table public.rewards enable row level security;
alter table public.reward_claims enable row level security;
alter table public.weight_entries enable row level security;
alter table public.wins enable row level security;

create policy "members read household" on public.households for select to authenticated
using (public.is_household_member(id));

create policy "members read profiles" on public.profiles for select to authenticated
using (id = auth.uid() or (household_id is not null and public.is_household_member(household_id)));
create policy "user insert own profile" on public.profiles for insert to authenticated
with check (id = auth.uid());
create policy "user update own profile" on public.profiles for update to authenticated
using (id = auth.uid()) with check (id = auth.uid());

create policy "members read habits" on public.habits for select to authenticated
using (public.is_household_member(household_id));
create policy "members create habits" on public.habits for insert to authenticated
with check (public.is_household_member(household_id) and (owner_user_id is null or owner_user_id = auth.uid()));
create policy "owner or member update habits" on public.habits for update to authenticated
using (public.is_household_member(household_id) and (owner_user_id is null or owner_user_id = auth.uid()))
with check (public.is_household_member(household_id) and (owner_user_id is null or owner_user_id = auth.uid()));

create policy "user reads own checkins" on public.check_ins for select to authenticated using (user_id = auth.uid());
create policy "user inserts own checkins" on public.check_ins for insert to authenticated with check (user_id = auth.uid());
create policy "user updates own checkins" on public.check_ins for update to authenticated
using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "user deletes own checkins" on public.check_ins for delete to authenticated using (user_id = auth.uid());

create policy "members read rewards" on public.rewards for select to authenticated
using (public.is_household_member(household_id) and (reward_type = 'shared' or owner_user_id = auth.uid()));
create policy "members create rewards" on public.rewards for insert to authenticated
with check (public.is_household_member(household_id) and (reward_type = 'shared' or owner_user_id = auth.uid()));
create policy "owners update rewards" on public.rewards for update to authenticated
using (public.is_household_member(household_id) and (reward_type = 'shared' or owner_user_id = auth.uid()))
with check (public.is_household_member(household_id) and (reward_type = 'shared' or owner_user_id = auth.uid()));

create policy "claimant or household reads claims" on public.reward_claims for select to authenticated
using (claimed_by = auth.uid() or exists (
  select 1 from public.rewards r where r.id = reward_id and r.reward_type = 'shared'
  and public.is_household_member(r.household_id)
));
create policy "user claims reward" on public.reward_claims for insert to authenticated
with check (claimed_by = auth.uid());

create policy "user manages own weight" on public.weight_entries for all to authenticated
using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "user manages own wins" on public.wins for all to authenticated
using (user_id = auth.uid()) with check (user_id = auth.uid());

-- Important: implement and test server-side validation for weekly bonuses and reward spending.
-- Seed habits and create the initial household through a trusted setup step.
