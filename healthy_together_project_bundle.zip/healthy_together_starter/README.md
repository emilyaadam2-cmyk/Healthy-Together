# Healthy Together

A phone-first starter project for Emily and David. This is a starter project, not a deployed app.

## What is included
- `index.html`: mobile-first app shell with login, habit check-ins, progress, rewards, private weight log, and settings.
- `supabase/schema.sql`: reference schema from the initial project plan. **Do not rerun it on the existing database**; the live project has already been modified and must be migrated carefully.
- `APP_PLAN.md`: agreed product behavior and design direction.
- `.env.example`: environment-variable reference for a future build setup.

## Important
The current Supabase project has already been modified in the dashboard. Before connecting this interface to real user data, the live table definitions and row-level-security policies need to be checked against the interface. Do not use a Supabase `service_role` key in browser code. Never enter real weight data until privacy rules have been tested with both accounts.

The HTML file can be previewed locally, but the Supabase-connected features require the project URL, publishable/anon key, and compatible tables/policies. Hosting and authentication setup are still required; this bundle is not a live deployed app.
